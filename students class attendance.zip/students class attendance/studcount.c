#include <stdio.h>
#include "STUDENT.h"
int curcount()
{
    int n;
    cur=fopen("STUDENTS_DATA.dat","rb");
    if(cur==NULL)
      return 0;
    fseek(cur,0,SEEK_END);
    n=ftell(cur)/sizeof(STUD);
    fclose(cur);
    return n;
}
int oldcount()
{
    int n;
    old=fopen("BACKUP.dat","rb");
    if(old==NULL)
      return 0;
    fseek(old,0,SEEK_END);
    n=ftell(old)/sizeof(STUD);
    fclose(old);
    return n;
}
int studcount()
{
   int count;
   int curcount(void);
   int oldcount(void);
   count=curcount() + oldcount();
   return count;
}

