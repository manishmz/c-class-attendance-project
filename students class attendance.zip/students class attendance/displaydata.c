#include <stdio.h>
#include <conio.h>
#include <math.h>
#include "STUDENT.h"
void showview()
{
    int x,y;
     clrscr();
    textcolor(15);
    textbackground(4);
    for(x=2; x<=80; x++)
    {
        gotoxy(x,3);
        cprintf("*");
        gotoxy(x,5);
        cprintf("*");
        gotoxy(x,22);
        cprintf("*");
    }
    for(y=3; y<=22; y++)
    {
       gotoxy(2,y);
       cprintf("*");
       gotoxy(80,y);
       cprintf("*");
    }

}
void readdata(FILE*temp,int ns)
{
    int i;
    extern STUD s;
    float aggr;
    textcolor(0);
    textbackground(15);
    gotoxy(4,4);
    cprintf("RegNo.");
    gotoxy(13,4);
    cprintf("First Name");
    gotoxy(25,4);
    cprintf("Last Name");
    gotoxy(42,4);
    cprintf("Email");
    gotoxy(55,4);
    cprintf("Contact");
    gotoxy(66,4);
    cprintf("RollNo.");
    gotoxy(74,4);
    cprintf("Attd.");
    for(i=1; i<=ns; i++)
    {
      fread(&s,sizeof(STUD),1,temp);

      gotoxy(4,5+i);
      cprintf("%s",s.regid);
      gotoxy(16,5+i);
      cprintf("%s",s.fname);
      gotoxy(26,5+i);
      cprintf("%s",s.lname);
      gotoxy(38,5+i);
      cprintf("%s",s.email);
      gotoxy(58,5+i);
      cprintf("%s",s.contact);
      gotoxy(70,5+i);
      cprintf("%d",s.roll);

     aggr=(s.present*100)/s.total;
      gotoxy(75,5+i);

      cprintf("%.0f%",ceil(aggr));

    }
    fclose(cur);
}
void showcurrent_data(char*filename)
{
   extern int ns;
   int curcount(void);
   void showview(void);
   clrscr();
   showview();
   ns=curcount();
   if(ns==0)
   {
      gotoxy(38,11);
      cprintf("NO DATA TO DISPLAY");
      return;
   }
   cur=fopen(filename,"rb");
   readdata(cur,ns);
   _getch();
   return;

}
void showbackup_data(char*filename)
{
  extern int ns;
  extern FILE*old;
  int oldcount(void);
  void showview(void);
  clrscr();
  showview();
  ns=oldcount();
  if(ns==0)
  {
     gotoxy(38,11);
     cprintf("NO DATA TO DISPLAY");
  }
  old=fopen(filename,"rb");
   readdata(old,ns);
   _getch();
   return;
}

