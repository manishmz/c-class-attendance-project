#include <stdio.h>
#include <stdlib.h>

int main()
{
     void readpassword(void);
         printf("\n\n\t\t\tWelcome to Class Attendance Application\n\n");

    readpassword();
    return 0;
}
