#include <stdio.h>
#include <conio.h>
#include <dos.h>
#include "STUDENT.h"
void addview()
{
    int x,y;
     clrscr();
    textcolor(15);
    textbackground(4);
    for(x=5; x<=76; x++)
    {
        gotoxy(x,3);
        cprintf("*");
        gotoxy(x,22);
        cprintf("*");
    }
    for(y=3; y<=22; y++)
    {
       gotoxy(5,y);
       cprintf("**");
       gotoxy(76,y);
       cprintf("**");
    }

}
void insertdata()
{
    extern STUD s;
    extern int ns;
    extern FILE*cur;
    struct date d;
    void addview(void);
    int studcount(void);
    clrscr();
    addview();
    ns=studcount();
    getdate(&d);
    sprintf(s.regid,"%dBCS%d",d.da_year,++ns);

    gotoxy(13,5);
    cprintf("REG. No.:%s ",s.regid);

    gotoxy(13,7);
    cprintf("Enter First Name: ");
    fflush(stdin);
    fgets(s.fname,12,stdin);

    gotoxy(13,9);
    cprintf("Enter Last Name: ");
    fflush(stdin);
    fgets(s.lname,12,stdin);

    gotoxy(13,11);
    cprintf("Enter Email id: ");
    fflush(stdin);
    fgets(s.email,20,stdin);

    gotoxy(13,13);
    cprintf("Contact No : ");
    scanf("%s",&s.contact);
    s.present=0;
    s.roll=ns;
    s.total=0;
    cur=fopen("STUDENTS_DATA.dat","ab");
    fwrite(&s,sizeof(STUD),1,cur);
    fclose(cur);
    return;

}

