
#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <process.h>
#include "STUDENT.h"
void updatedata()
{
    void searchview(void);
    int curcount(void);
    char tempid[10];
    extern int ns;
    int i,flag=0;
    extern FILE*cur;
    extern STUD s;
    searchview();
    textcolor(15);
    textbackground(4);
    gotoxy(10,5);
    cprintf("ENTER REG. ID: ");
    scanf("%s",tempid);
    ns=curcount();
    if(ns==0)
    {
      gotoxy(38,11);
      cprintf("NO DATA TO UPDATE");
      return;
    }
    cur=fopen("STUDENTS_DATA.dat","rb+");
    for(i=1; i<=ns; i++)
    {
      fread(&s,sizeof(STUD),1,cur);
      if(stricmp(tempid,s.regid)==0)
      {
          flag=1;
           gotoxy(8,7);
           cprintf("%s",s.regid);
           gotoxy(19,7);
           cprintf("%s",s.fname);
           gotoxy(28,7);
           cprintf("%s",s.lname);
           gotoxy(41,7);
           cprintf("%s",s.email);
           gotoxy(63,7);
           cprintf("%s",s.contact);

           gotoxy(10,9);
           cprintf("Enter First Name: ");
           fflush(stdin);
           fgets(s.fname,12,stdin);

           gotoxy(10,11);
           cprintf("Enter Last Name: ");
           fflush(stdin);
            fgets(s.lname,12,stdin);

           gotoxy(10,13);
            cprintf("Enter Email id: ");
            fflush(stdin);
            fgets(s.email,20,stdin);

            gotoxy(10,15);
            cprintf("Enter Contact No. : ");
           fflush(stdin);
            fgets(s.contact,10,stdin);

            fseek(cur,sizeof(STUD)*(i-1),SEEK_SET);
            fwrite(&s,sizeof(STUD),1,cur);

            break;
       }
    }
    fclose(cur);
    if(flag==0)
    {

      gotoxy(38,11);
      cprintf("RECORD NOT FOUND");
      return;
    }
    else
    {
       gotoxy(38,11);
      cprintf("RECORD IS UPDATED");
      return;
    }

}
