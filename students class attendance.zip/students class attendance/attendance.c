#include <stdio.h>
#include <conio.h>
#include "STUDENT.h"
void view()
{
    int x,y;
     clrscr();
    textcolor(15);
    textbackground(4);
    for(x=5; x<=65; x++)
    {
        gotoxy(x,3);
        cprintf("*");
        gotoxy(x,5);
        cprintf("*");
        gotoxy(x,22);
        cprintf("*");
    }
    for(y=3; y<=22; y++)
    {
       gotoxy(4,y);
       cprintf("**");
       gotoxy(66,y);
       cprintf("**");
    }

}
void displaydata(char*filename,int ns)
{
    int i;
    extern STUD s;
    cur=fopen(filename,"rb");
    textcolor(0);
    textbackground(15);
    gotoxy(7,4);
    cprintf("RegNo.");
    gotoxy(18,4);
    cprintf("First Name");
    gotoxy(31,4);
    cprintf("Last Name");
    gotoxy(45,4);
    cprintf("Roll no.");
    gotoxy(56,4);
    cprintf("P/A");

    for(i=1; i<=ns; i++)
    {
      fread(&s,sizeof(STUD),1,cur);

      gotoxy(7,5+i);
      cprintf("%s",s.regid);
      gotoxy(19,5+i);
      cprintf("%s",s.fname);
      gotoxy(32,5+i);
      cprintf("%s",s.lname);
      gotoxy(48,5+i);
      cprintf("%d",s.roll);
    }
    fclose(cur);
}
void takeattendance(char*filename)
{
   extern int ns;
   extern STUD s;
   extern FILE*cur;
   int i;
   char att[1];
   int curcount(void);
   void view(void);

   clrscr();
   view();
   ns=curcount();
   if(ns==0)
   {
      gotoxy(38,11);
      cprintf("NO DATA TO DISPLAY");
      return;
   }

   displaydata(filename,ns);
   cur=fopen(filename,"rb+");
    for(i=1; i<=ns; i++)
    {
      gotoxy(57,5+i);
      scanf("%s",att);
      fread(&s,sizeof(STUD),1,cur);
      s.total=s.total+1;
      if(stricmp(att,"p")==0)
      {
        s.present=s.present+1;
      }
        fseek(cur,sizeof(STUD)*(i-1),SEEK_SET);
        fwrite(&s,sizeof(STUD),1,cur);
        fseek(cur,sizeof(STUD)*(i),SEEK_SET);
    }
    fclose(cur);
       _getch();
   return;

}
