#include <stdio.h>
#include <conio.h>
#include "STUDENT.h"
void searchview()
{
    int x,y;
     clrscr();
    textcolor(15);
    textbackground(4);
    for(x=5; x<=76; x++)
    {
        gotoxy(x,3);
        cprintf("*");
        gotoxy(x,22);
        cprintf("*");
    }
    for(y=3; y<=22; y++)
    {
       gotoxy(5,y);
       cprintf("**");
       gotoxy(76,y);
       cprintf("**");
    }

}
void searchcurrent_data()
{
    void searchview(void);
    int curcount();
    char tempid[10];
    extern int ns;
    int i,flag=0,j;
    extern FILE*cur;
    extern STUD s;
    searchview();
    textcolor(15);
    textbackground(4);
    gotoxy(10,5);
    cprintf("ENTER REG. ID: ");
    fflush(stdin);
    fgets(tempid,10,stdin);
    ns=curcount();
    if(ns==0)
    {
      gotoxy(38,11);
      cprintf("NO DATA TO SEARCH");
      return;
    }
    cur=fopen("STUDENTS_DATA.dat","rb");
    for(i=1; i<=ns; i++)
    {
      fread(&s,sizeof(STUD),1,cur);

      if(stricmp(tempid,s.regid)==0)
      {
          gotoxy(10,7);
          cprintf("First Name:%s",s.fname);
          gotoxy(10,9);
          cprintf("Last Name:%s",s.lname);
          gotoxy(10,11);
          cprintf("Email Id:%s",s.email);
          gotoxy(10,13);
          cprintf("Contact:%s",s.contact);
          gotoxy(10,15);
          cprintf("Attendance:%d",s.present);
          flag=1;
          break;
       }
    }
    fclose(cur);
    if(flag==0)
    {
      gotoxy(38,11);
      cprintf("RECORD NOT FOUND");
      return;
    }
    return;
}

