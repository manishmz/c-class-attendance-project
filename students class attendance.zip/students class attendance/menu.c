#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include "STUDENT.h"
 STUD s;
    int ns;
    FILE*cur,*old;
void menu()
{
    int x,y;
    char choice;
    void takeattendance(char*);
    void insertdata(void);
    void showcurrent_data(char*);
    void showbackup_data(char*);
    void searchcurrent_data(void);
    void updatedata(void);
    void deletedata(void);
    textcolor(1);
    textbackground(2);
    do{
    clrscr();
    for(x=8;x<=70;x++)
    {
           gotoxy(x,3);
           cprintf("*");
           gotoxy(x,25);
        cprintf("*");

    }
    for(y=3;y<=25;y++)
    {
           gotoxy(8,y);
           cprintf("+");
           gotoxy(70,y);
        cprintf("+");

    }

    textcolor(0);
    gotoxy(10,5);
    cprintf("1:Take Attendance....:");
    gotoxy(10,7);
    cprintf("2:Add Student....:");
    gotoxy(10,9);
    cprintf("3:Student Info....:");
    gotoxy(10,11);
    cprintf("4.Display Backup....: ");
    gotoxy(10,13);
    cprintf("5.Search Student.....: ");
    gotoxy(10,15);
    cprintf("6.Update Student Info.....: ");
    gotoxy(10,17);
    cprintf("7.Delete Student Info.....: ");
    gotoxy(10,19);
    cprintf("8.Exit Program......: ");
    gotoxy(10,21);
    cprintf("Enter Your choice...: ");
    choice=_getch();
     switch(choice)
        {
             case '1': takeattendance("STUDENTS_DATA.dat");
                       break;
            case '2': insertdata();
                       break;
            case '3': showcurrent_data("STUDENTS_DATA.dat");
                       break;
            case '4': showbackup_data("BACKUP.dat");
                       break;
            case '5': searchcurrent_data();
                       break;
            case '6': updatedata();
                        break;
           case '7': deletedata();
                        break;
            case '8': clrscr();
                      exit(0);

            default: gotoxy(38,21);
                     cprintf("invalid choice: ");

        }
        gotoxy(38,23);
        cprintf("Do You Want to Continue Y?: ");
        fflush(stdin);
        choice=getchar();
    }while(choice=='Y'||choice=='y');
    return;

}
