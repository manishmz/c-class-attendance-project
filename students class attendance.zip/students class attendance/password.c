
#include<stdio.h>
#include<stdlib.h>

void readpassword()
{
    char pass[]="manish";
    char *getp;
    void menu(void);
    getp=getpass("Enter password : ");
    if(strcmp(getp,pass)==0)
    {
        menu();
    }
    else{
            textcolor(4);
        cprintf("Wrong Password\n");

    }
}
