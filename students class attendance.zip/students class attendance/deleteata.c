
#include <stdio.h>
#include <conio.h>
#include <string.h>
#include "STUDENT.h"
void deletedata()
{
    void searchview(void);
    int curcount(void);
    char tempid[10];
    extern int ns;
    int i,flag=0;
    extern FILE*cur;
    extern FILE*old;
    FILE*temp;
    extern STUD s;
    searchview();
    textcolor(15);
    textbackground(4);
    gotoxy(10,5);
    cprintf("ENTER EMP ID: ");
    scanf("%s",tempid);
    ns=curcount();
    if(ns==0)
    {
      gotoxy(38,11);
      cprintf("NO DATA TO DELETE");
      return;
    }
    cur=fopen("STUDENTS_DATA.dat","rb");
    old=fopen("BACKUP.dat","ab");
    temp=fopen("TEMP.dat","wb");

    for(i=1; i<=ns; i++)
    {
      fread(&s,sizeof(STUD),1,cur);
      if(stricmp(tempid,s.regid)==0)
      {
         flag=1;
         fwrite(&s,sizeof(STUD),1,old);
      }
      else
        fwrite(&s,sizeof(STUD),1,temp);
    }
    fclose(cur);
    fclose(old);
    fclose(temp);
    remove("STUDENTS_DATA.dat");
    rename("TEMP.dat","STUDENTS_DATA.dat");
    if(flag==0)
    {
      gotoxy(38,11);
      cprintf("RECORD NOT FOUND");
      return;
    }
    else
    {
       gotoxy(38,11);
      cprintf("RECORD IS DELETED");
      return;
    }

}
