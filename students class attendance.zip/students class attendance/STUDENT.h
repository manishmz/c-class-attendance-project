#ifndef STUDENT_H_INCLUDED
#define STUDENT_H_INCLUDED
typedef struct
{
    char regid[10];
    char fname[12];
    char lname[12];
    char email[20];
    char contact[10];
    unsigned int roll;
    int present;
    int total;
}STUD;

extern STUD s;
extern int ns;
extern FILE*cur,*old;
#endif
